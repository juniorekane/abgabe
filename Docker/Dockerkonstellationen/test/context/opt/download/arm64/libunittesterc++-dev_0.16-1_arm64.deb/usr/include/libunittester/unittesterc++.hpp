/*
  This file is part of Tester-Unit-Testing.

  Tester-Unit-Testing is free software: you can redistribute it and/or
  modify it under the terms of the GNU General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Tester-Unit-Testing is distributed in the hope that it will be
  useful, but WITHOUT ANY WARRANTY; without even the implied warranty
  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Tester-Unit-Testing. If not, see
  <https://www.gnu.org/licenses/>.

  Copyright (C) 2022 Henrik Lipskoch
*/

/*!
  \file unittesterc++.hpp
  \brief Test-code to support development using the C++ programming language
   with tests

  \details Tester provides methods to compare values

  \author Henrik Lipskoch
*/

#ifndef _UNITTESTERCPP_HPP
#define _UNITTESTERCPP_HPP 1

// for complex numbers
#include <complex>
// for strings
#include <string>
// for deque, initializer_list
#include <deque>
// for exception
#include <exception>

/*************** test definition: start ***************************************/

/*!
  \brief Defines a test

  \details a test is named, is assigned a test method, and is assigned an
  expected return value.

  Tests must run without parameters. If you need parameterisation write a test
  method that runs the parameterised tests.

  An implementation of a test method may look like

  ~~~{.cpp}
  int testMyVeryNiceMethod()
  {
    char const * myText = myNiceMethod("Argument");
    assertEquals("Hallo Welt", myText, "Text für \"Argument\"");
    // will never have an error
    return 0;
  }
  ~~~

  A common test can be created as follows, assuming its expected return value
  upon success is 0:

  ~~~{.cpp}
  CommonTest("Tests myNiceMethod with argument",
             testMyVeryNiceMethod);
  ~~~

  \attention Wy does a test method need a return value?

  The programming language C++ provides the concept of exceptions, and
  exceptions could be used to indicate errors during testing. Instead,
  unittester uses error codes in return values. Only in this way the success or
  error of a run is verified, and real exceptions are treated as real errors,
  i.e. abnormal operation.

  Before the test itself is started, prepartions are done according to
  method beforeTestMethod which may build up data structures, load data into
  internal states of the object to be tested. After the test, the method
  afterTestMethod is executed to free memory, unload data, or to perform other
  post-test activities.

  A successful test is to be expected to return 0.

  A test is only run if the preparating method returned 0, or the
  method pointer is NULL.

  To run a CommonTest put it into Tester.
*/
class CommonTest
{
public:
  /*!
    \brief Name of the test
  */
  std::string const name;

  /*!
    \brief expected return value

    \details For all methods, the value contains an error code of the test. If
    it is 0, then a successful execution is assumed.
  */
  int const expectedReturnValue;

  /*!
    \brief Test method

    \details In the programming language C you just write the methods name here.
  */
  int (* const testMethod)();

  /*!
    \brief Method to prepare the test

    \details give here a method to prepare test, e.g.
    \li create datastructures
    \li prepare test data

    if the test has no preparing method then set this to NULL
    */
  int (* const beforeTestMethod)();

  /*!
    \brief Method to conclude the test

    \details give here a method to conclude tests, e.g.
    \li free datastructures
    \li free test data
    \li collect data or results

    if the test has no concluding method then set this to NULL
   */
  int (* const afterTestMethod)();
 
  /*!
    \brief Constructor

    \param[in] pName         name of the test
    \param[in] pReturnValue  expected value to be returned be pTestMethod
    \param[in] pTestMethod   method to run
  */
  CommonTest(char const * pName,
             int const pReturnValue,
             int (*pTestMethod)()) noexcept;

  /*!
    \brief Constructor

    \param[in] pName         name of the test
    \param[in] pTestMethod   method to run
  */
  CommonTest(char const * pName,
             int (*pTestMethod)()) noexcept;

  /*!
    \brief Constructor

    \param[in] pName         name of the test
    \param[in] pTestMethod   method to run, the test
    \param[in] pReturnValue  expected value to be returned be pTestMethod
    \param[in] pBeforeTestMethod  preparing method, to be run before the test
    \param[in] pAfterTestMethod   concluding method, to be run after the test
  */
  CommonTest(char const * pName,
             int const pReturnValue,
             int (* const pTestMethod)(),
             int (* const pBeforeTestMethod)(),
             int (* const pAfterTestMethod)()) noexcept;

  /*!
    \brief Copy constructor
    
    \param[in] pTest  test to copy
  */
  CommonTest(CommonTest const & pTest) noexcept;

  /*!
    \brief Destructor
  */
  ~CommonTest();
};

/*!
  \brief Defines a test-suite

  \details A suite is a list of tests to run and a name for that list. The
  results are recorded in a protocol, and name and protocol are printed in the
  output.

  The suite may have a preparing and a concluding method to do
  preparations before the first test runs and to do after work after
  the last test ran.

  If a preparing method returns a non-zero value no test will run, and
  if the concluding method returns a non-zero value, the suite will
  end with status fail.
*/
class TestSuite
{
public:
  /*!
    \brief Name of the suite
  */
  std::string const name;

  /*!
    \brief Tests to run, organized in a queue
   */
  std::deque<CommonTest> const testsToRun;

  /*!
    \brief Method to prepare the test suite

    \details give here a method to prepare tests, e.g.
    \li create common datastructures
    \li initialise globals
    \li prepare test data

    if the test suite has no preparing method then set this to NULL
   */
  int (* const beforeTestSuite)();

  /*!
    \brief Method to conclude the test suite

    \details give here a method to conclude tests, e.g.
    \li free common datastructures
    \li destroy globals
    \li free test data
    \li collect global data

    if the test suite has no concluding method then set this to NULL
   */
  int (* const afterTestSuite)();

  /*!
    \brief Constructor

    \param[in] name       name of the test suite
    \param[in] testsToRun  tests to be run by the suite
  */
  TestSuite(char const * name,
            std::initializer_list<CommonTest> const & testsToRun);

  /*!
    \brief Constructor

    \param[in] name       name of the test suite
    \param[in] testsToRun  tests to be run by the suite
    \param[in] beforeTestSuite
                           method to prepare the run of all tests of the suite
    \param[in] afterTestSuite
                           method to conclude the run of all tests of the suite
  */
  TestSuite(char const * name,
            std::initializer_list<CommonTest> const & testsToRun,
            int (* const beforeTestSuite)(),
            int (* const afterTestSuite)());

  /*!
    \brief Copy constructor

    \param[in] pSuite  element to be copied
  */
  TestSuite(TestSuite const & pSuite);

  /*!
    \brief Destructor
  */
  ~TestSuite();
};


/*************** test run and invocation: start *******************************/

/*!
  \brief Tester is the starting point for your tests

  \details configure tester with command line options, define tests using
  CommonTest and bundle these with TestSuite, and then run tester with the suite
*/
class Tester
{
public:

  /*!
    \brief Walks through the command-line parameters and configures tester

    \details Parameters are

    | Name              | Meaning                                              |
    |-------------------|------------------------------------------------------|
    | -h, --help        | Prints the help text and stops further execution     |
    | --no-colours      | Disables colours, default: ANSI colours are enabled  |
    | --only-errors     | Prints failed asserts, and summary over all          |
    | --only-summary    | Prints only the summary                              |
    | --output `MyFile` | Directs output into file `MyFile`; coloured output   |
    |                 ^ | is then disabled                                     |
    
    Output is formatted according to Markdown rules. If some parameters do not
    match this is output to console.

    \param[in] argumentCount     number of parameters
    \param[in] arguments         list of parameter, the first element in the
                                 list is assumed to contain the name of the
                                 program called by the shell; the name is used
                                 in the help text
    \return a Tester object, configured according to parameters
  */
  static Tester & configure(int argumentCount, char * const * const arguments);

  /*!
    \brief Runs a single test

    \param[in] test test to be run

    \retval 0   test ran and no errors occurred
    \retval -1  test ran and produced a wrong return value
    \retval -2  test did not run because of an error in the configuration, see
                Tester::configure(int, char * const *)
    \retval -3  in case the preparation failed, i.e. method
                beforeTestMethod returned a non-zero value
    \retval -4  in case concluding work failed, i.e. method
                afterTestMethod returned a non-zero value
  */
  virtual int runSingle(CommonTest const & test) = 0;

  /*!
    \brief Runs a test suite

    \param[in]  suite  test suite to run

    \retval 0   suite ran and no errors occurred
    \retval -2  suite did not run because of an error in the configuration, see
                Tester::configure(int, char * const *)
    \retval p   positive value, giving the number of unsuccessful tests
    \retval -3  in case the preparation failed, i.e. method
                beforeSuiteMethod returned a non-zero value
    \retval -4  in case concluding work failed, i.e. method
                afterSuiteMethod returned a non-zero value               
  */
  virtual int runSuite(TestSuite const & suite) = 0;

  /*!
    \brief Destructor
  */
  virtual ~Tester();

protected:

  /*!
    \brief Constructor
  */
  Tester();

private:
  /*!
    \brief Copy constructor

    \param[in] t Tester to copy
  */
  Tester(Tester const & t);

  /*!
    \brief Copy operator

    \param[in] t Tester to copy
  */
  Tester & operator=(Tester const & t);
};

/*************** test run and invocation: end *********************************/

/*************** test definition: end *****************************************/

/*************** test logging: start ******************************************/

/*!
  \brief Prints into the test output

  \details Called within methods beforeTestMethod and afterTestMethod, this
  output is written into a Markdown formatted code-block.

  \param[in] message  message to log
*/
void testerLog(std::string const & message);

/*************** test logging: end ********************************************/

/*************** assertions: start ********************************************/

/*************** assertions - integer types: start ****************************/

/*!
  \brief Compares two int values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(int expected,
                  int actual,
                  std::string const & message);

/*!
  \brief Compares two unsigned int values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned int expected,
                  unsigned int actual,
                  std::string const & message);

/*!
  \brief Compares two char values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(char expected,
                  char actual,
                  std::string const & message);

/*!
  \brief Compares two signed char values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(signed char expected,
                  signed char actual,
                  std::string const & message);

/*!
  \brief Compares two unsigned char values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned char expected,
                  unsigned char actual,
                  std::string const & message);

/*!
  \brief Compares two long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long expected,
                  long actual,
                  std::string const & message);

/*!
  \brief Compares two unsigned long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned long expected,
                  unsigned long actual,
                  std::string const & message);

/*!
  \brief Compares two long long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long long int expected,
                  long long int actual,
                  std::string const & message);

/*!
  \brief Compares two unsigned long long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned long long int expected,
                  unsigned long long int actual,
                  std::string const & message);

/*************** assertions - integer types: end ******************************/

/*************** assertions - floating-point types: start *********************/

/*!
  \brief Compares two double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(double expected,
                  double actual,
                  std::string const & message);

/*!
  \brief Compares two long double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long double expected,
                  long double actual,
                  std::string const & message);

/*!
  \brief Compares two complex double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::complex<double> expected,
                  std::complex<double> actual,
                  std::string const & message);

/*!
  \brief Compares two complex long double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::complex<long double> expected,
                  std::complex<long double> actual,
                  std::string const & message);

/*************** assertions - floating-point types: end ***********************/

/*************** assertions - arrays: start ***********************************/

/*!
  \brief Compares two int arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(int const expected[],
                  int expectedLength,
                  int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two unsigned int arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned int const expected[],
                  int expectedLength,
                  unsigned int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two char arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(char const expected[],
                  int expectedLength,
                  char const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two char arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(signed char const expected[],
                  int expectedLength,
                  signed char const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two unsigend char arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned char const expected[],
                  int expectedLength,
                  unsigned char const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long int const expected[],
                  int expectedLength,
                  long int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two unsigned long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned long int const expected[],
                  int expectedLength,
                  unsigned long int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two long long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long long int const expected[],
                  int expectedLength,
                  long long int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two unsigned long long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(unsigned long long int const expected[],
                  int expectedLength,
                  unsigned long long int const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(double const expected[],
                  int expectedLength,
                  double const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two long double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(long double const expected[],
                  int expectedLength,
                  long double const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two complex double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::complex<double> const expected[],
                  int expectedLength,
                  std::complex<double> const actual[],
                  int actualLength,
                  std::string const & message);

/*!
  \brief Compares two long complex double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::complex<long double> const expected[],
                  int expectedLength,
                  std::complex<long double> const actual[],
                  int actualLength,
                  std::string const & message);

/*************** assertions - arrays: end *************************************/

/*************** assertions - strings: start **********************************/

/*!
  \brief Compares two strings, texts, on equality

  \param[in] expected the expected text
  \param[in] actual   the actual text to be checked
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::string const & expected,
                  std::string const & actual,
                  std::string const & message);

/*!
  \brief Compares two string arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
 */
void assertEquals(std::string const expected[],
                  int expectedLength,
                  std::string const actual[],
                  int actualLength,
                  std::string const & message);

/*************** assertions - arrays: end *************************************/

/*************** assertions - pointers types: start ***************************/

/*!
  \brief Compares two pointers to point to the same memory, or to contain both
  the value NULL

  \param[in] expected the expected pointer from int
  \param[in] actual   the actual pointer from int
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(int const * const expected,
                         int const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from unsigned integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned integer
  \param[in] actual   the actual pointer from unsigned integer
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(unsigned int const * const expected,
                         unsigned int const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers to point to the same memory, or to contain both
  the value NULL

  \param[in] expected the expected pointer from char
  \param[in] actual   the actual pointer from char
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(char const * const expected,
                         char const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers to point to the same memory, or to contain both
  the value NULL

  \param[in] expected the expected pointer from char
  \param[in] actual   the actual pointer from char
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(signed char const * const expected,
                         signed char const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from unsigned char
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned char
  \param[in] actual   the actual pointer from unsigned char
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(unsigned char const * const expected,
                         unsigned char const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from long
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long integer
  \param[in] actual   the actual pointer from long integer
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(long const * const expected,
                         long const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from unsigned long
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned long
  \param[in] actual   the actual pointer from unsigned long
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(unsigned long const * const expected,
                         unsigned long const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from long long integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long long integer
  \param[in] actual   the actual pointer from long long integer
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(long long int const * const expected,
                         long long int const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from unsigned long long integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned long long integer
  \param[in] actual   the actual pointer from unsigned long long integer
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(unsigned long long int const * const expected,
                         unsigned long long int const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from double
  \param[in] actual   the actual pointer from double
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(double const * const expected,
                         double const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from long double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long double
  \param[in] actual   the actual pointer from long double
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(long double const * const expected,
                         long double const * const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from double complex
  \param[in] actual   the actual pointer from double complex
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(std::complex<double> const * const expected,
                         std::complex<double> const * const actual,
                         std::string const& message);

/*!
  \brief Compares two pointers from long double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long double complex
  \param[in] actual   the actual pointer from long double complex
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(std::complex<long double> const * const expected,
                         std::complex<long double> const* const actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from string
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from string
  \param[in] actual   the actual pointer from string
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(char const * const * expected,
                         char const * const * actual,
                         std::string const & message);

/*!
  \brief Compares two pointers from void
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from void
  \param[in] actual   the actual pointer from void
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameters
*/
void assertEqualsPointer(void const * const expected,
                         void const * const actual,
                         std::string const & message);

/*!
  \brief Checks a pointer to point to something

  \param[in] actual  the actual pointer from void
  \param[in] message  descriptive message for the check, assert, providing
                      information about the comparision or the parameter
*/
void assertNotNull(void const * const actual,
                   std::string const & message);

/*************** assertions - pointers types: end *****************************/

/*************** assertions - boolean and fail: start *************************/

/*!
  \brief Checks a logical value if it is true

  \param[in] actual  the actual value to be checked
  \param[in] message  descriptive message for the check
*/
void assertTrue(bool actual,
                std::string const & message);

/*!
  \brief Checks a logical value if it is false

  \param[in] actual  the actual value to be checked
  \param[in] message  descriptive message for the check
*/
void assertFalse(bool actual,
                 std::string const & message);

/*!
  \brief Lets the test fail and outputs an error message

  \param[in] message  descriptive message for the failure to report
*/
void fail(std::string const & message);

/*************** assertions - boolean and fail: end ***************************/

/*************** assertions: end **********************************************/

#endif // _UNITTESTERCPP_HPP
