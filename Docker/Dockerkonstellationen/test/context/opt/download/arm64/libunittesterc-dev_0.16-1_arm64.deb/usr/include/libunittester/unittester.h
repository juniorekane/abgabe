/*
  This file is part of Tester-Unit-Testing.

  Tester-Unit-Testing is free software: you can redistribute it and/or
  modify it under the terms of the GNU General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Tester-Unit-Testing is distributed in the hope that it will be
  useful, but WITHOUT ANY WARRANTY; without even the implied warranty
  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Tester-Unit-Testing. If not, see
  <https://www.gnu.org/licenses/>.

  Copyright (C) 2022 Henrik Lipskoch
*/

/*!
  \file unittester.h
  \brief Test-code to support development with tests

  \details Tester provides methods to compare values

  \author Henrik Lipskoch
*/

#ifndef _UNITTESTER_H
#define _UNITTESTER_H 1

#include <stdbool.h>

/*************** test definition: start ***************************************/

/*!
  \brief Defines a test

  \details a test is named, is assigned a test method, and is assigned an
  expected return value.

  Tests must run without parameters. If you need parameterisation write a test
  method that runs the parameterised tests.

  An implementation of a test method may look like

  ~~~{.c}
  int testMyVeryNiceMethod(void)
  {
    char* myText = myNiceMethod("Argument");
    assertEqualsString("Hallo Welt", myText, "Text für \"Argument\"");
    // will never have an error
    return 0;
  }
  ~~~


  A test is included in the structure as follows:

  ~~~{.c}
  CommonTest t =
  {
    "Tests myNiceMethod with argument",
    0,
    testMyVeryNiceMethod
  };
  ~~~

  \attention Wy does a test method need a return value?

  The programming language C does not provide the concept of exceptions,
  instead, error codes are used as return values. Only in this way the success
  or error of a run can be verified. Other solutions like global variables, may
  not be designed for parallel execution of tests using multiple threads.

  The C standard library, for example, uses NULL as a value for unsuccessful
  memory allocation and sets a global error variable, errno. Though the value is
  thread-local, it is set by the next library call making it necessary to be
  saved between calls, making it difficult to use.

  Before the test itself is started, prepartions are done according to
  method beforeTestMethod which may build up data structures, load data into
  internal states of the object to be tested. After the test, the method
  afterTestMethod is executed to free memory, unload data, or to perform other
  post-test activities.

  A successful test is to be expected to return 0.

  A test is only run if the preparating method returned 0, or the
  method pointer is NULL.
*/
typedef struct CommonTest
{
  /*!
    \brief Name of the test
  */
  char* name;

  /*!
    \brief expected return value

    \details For all methods, the value contains an error code of the test. If
    it is 0, then a successful execution is assumed.
  */
  int expectedReturnValue;

  /*!
    \brief Test method

    \details In the programming language C you just write the methods name here.
  */
  int (*testMethod)(void);

  /*!
    \brief method to prepare the test

    \details give here a method to prepare test, e.g.
    \li create datastructures
    \li prepare test data

    if the test has no preparing method then set this to NULL
    */
  int (*beforeTestMethod)(void);

  /*!
    \brief method to conclude the test

    \details give here a method to conclude tests, e.g.
    \li free datastructures
    \li free test data
    \li collect data or results

    if the test has no concluding method then set this to NULL
   */
  int (*afterTestMethod)(void);
} CommonTest;

/*!
  \brief Defines a test-suite

  \details A suite is a list of tests to run and a name for that list

  The suite may have a preparing and a concluding method to do
  preparations before the first test runs and to do after work after
  the last test ran.

  If a preparing method returns a non-zero value no test will run, and
  if the concluding method returns a non-zero value, the suite will
  end with status fail.
*/
typedef struct TestSuite
{
  /*!
    \brief Name of the suite
  */
  char* name;

  /*!
    \brief Number of tests to run
  */
  int testsToRunLength;

  /*!
    \brief Array of tests to run
   */
  CommonTest* testsToRun;

  /*!
    \brief method to prepare the test suite

    \details give here a method to prepare tests, e.g.
    \li create common datastructures
    \li initialise globals
    \li prepare test data

    if the test suite has no preparing method then set this to NULL
   */
  int (*beforeTestSuite)(void);

  /*!
    \brief method to conclude the test suite

    \details give here a method to conclude tests, e.g.
    \li free common datastructures
    \li destroy globals
    \li free test data
    \li collect global data

    if the test suite has no concluding method then set this to NULL
   */
  int (*afterTestSuite)(void);
} TestSuite;

/*************** test definition: end *****************************************/

/*************** assertions: start ********************************************/

/*************** assertions - integer types: start ****************************/

/*!
  \brief Compares two int values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEquals(int expected,
                  int actual,
                  char const * messageFormat,
                  ...);

/*!
  \brief Compares two unsigned int values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsUnsigned(unsigned int expected,
                          unsigned int actual,
                          char const * messageFormat,
                          ...);

/*!
  \brief Compares two char values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsChar(char expected,
                      char actual,
                      char const * messageFormat,
                      ...);

/*!
  \brief Compares two unsigned char values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsUnsignedChar(unsigned char expected,
                              unsigned char actual,
                              char const * messageFormat,
                              ...);

/*!
  \brief Compares two short integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsShort(short int expected,
                       short int actual,
                       char const * messageFormat,
                       ...);

/*!
  \brief Compares two unsigned short integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsUnsignedShort(unsigned short int expected,
                               unsigned short int actual,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsLong(long expected,
                      long actual,
                      char const * messageFormat,
                      ...);

/*!
  \brief Compares two unsigned long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsUnsignedLong(unsigned long expected,
                              unsigned long actual,
                              char const * messageFormat,
                              ...);

/*!
  \brief Compares two long long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsLongLong(long long int expected,
                          long long int actual,
                          char const * messageFormat,
                          ...);

/*!
  \brief Compares two unsigned long long integer values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsUnsignedLongLong(unsigned long long int expected,
                                  unsigned long long int actual,
                                  char const * messageFormat,
                                  ...);

/*************** assertions - integer types: end ******************************/

/*************** assertions - floating-point types: start *********************/

/*!
  \brief Compares two float values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsFloat(float expected,
                       float actual,
                       char const * messageFormat,
                       ...);

/*!
  \brief Compares two double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsDouble(double expected,
                        double actual,
                        char const * messageFormat,
                        ...);

/*!
  \brief Compares two long double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsLongDouble(long double expected,
                            long double actual,
                            char const * messageFormat,
                            ...);

/*!
  \brief Compares two complex float values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsFloatComplex(float _Complex expected,
                              float _Complex actual,
                              char const * messageFormat,
                              ...);

/*!
  \brief Compares two complex double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsDoubleComplex(double _Complex expected,
                               double _Complex actual,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two complex long double values on equality

  \param[in] expected the expected value
  \param[in] actual   the actual value to check
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsLongDoubleComplex(long double _Complex expected,
                                   long double _Complex actual,
                                   char const * messageFormat,
                                   ...);

/*************** assertions - floating-point types: end ***********************/

/*************** assertions - arrays: start ***********************************/

/*!
  \brief Compares two int arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArray(int expected[],
                       int expectedLength,
                       int actual[],
                       int actualLength,
                       char const * messageFormat,
                       ...);

/*!
  \brief Compares two unsigned int arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayUnsigned(unsigned int expected[],
                               int expectedLength,
                               unsigned int actual[],
                               int actualLength,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two char arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayChar(char expected[],
                           int expectedLength,
                           char actual[],
                           int actualLength,
                           char const * messageFormat,
                           ...);

/*!
  \brief Compares two unsigend char arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayUnsignedChar(unsigned char expected[],
                                   int expectedLength,
                                   unsigned char actual[],
                                   int actualLength,
                                   char const * messageFormat,
                                   ...);

/*!
  \brief Compares two short-integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayShort(short int expected[],
                            int expectedLength,
                            short int actual[],
                            int actualLength,
                            char const * messageFormat,
                            ...);

/*!
  \brief Compares two unsigned short-integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayUnsignedShort(unsigned short int expected[],
                                    int expectedLength,
                                    unsigned short int actual[],
                                    int actualLength,
                                    char const * messageFormat,
                                    ...);

/*!
  \brief Compares two long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayLong(long int expected[],
                           int expectedLength,
                           long int actual[],
                           int actualLength,
                           char const * messageFormat,
                           ...);

/*!
  \brief Compares two unsigned long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayUnsignedLong(unsigned long int expected[],
                                   int expectedLength,
                                   unsigned long int actual[],
                                   int actualLength,
                                   char const * messageFormat,
                                   ...);

/*!
  \brief Compares two long long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayLongLong(long long int expected[],
                               int expectedLength,
                               long long int actual[],
                               int actualLength,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two unsigned long long integer arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayUnsignedLongLong(unsigned long long int expected[],
                                       int expectedLength,
                                       unsigned long long int actual[],
                                       int actualLength,
                                       char const * messageFormat,
                                       ...);

/*!
  \brief Compares two float arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayFloat(float expected[],
                            int expectedLength,
                            float actual[],
                            int actualLength,
                            char const * messageFormat,
                            ...);

/*!
  \brief Compares two double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayDouble(double expected[],
                             int expectedLength,
                             double actual[],
                             int actualLength,
                             char const * messageFormat,
                             ...);

/*!
  \brief Compares two long double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayLongDouble(long double expected[],
                                 int expectedLength,
                                 long double actual[],
                                 int actualLength,
                                 char const * messageFormat,
                                 ...);

/*!
  \brief Compares two complex float arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayFloatComplex(float _Complex expected[],
                                   int expectedLength,
                                   float _Complex actual[],
                                   int actualLength,
                                   char const * messageFormat,
                                   ...);

/*!
  \brief Compares two complex double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayDoubleComplex(double _Complex expected[],
                                    int expectedLength,
                                    double _Complex actual[],
                                    int actualLength,
                                    char const * messageFormat,
                                    ...);

/*!
  \brief Compares two long complex double arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayLongDoubleComplex(long double _Complex expected[],
                                        int expectedLength,
                                        long double _Complex actual[],
                                        int actualLength,
                                        char const * messageFormat,
                                        ...);

/*************** assertions - arrays: end *************************************/

/*************** assertions - strings: start **********************************/

/*!
  \brief Compares two strings, texts, on equality

  \param[in] expected the expected text
  \param[in] actual   the actual text to be checked
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsString(char * const expected,
                        char * const actual,
                        char const * messageFormat,
                        ...);

/*!
  \brief Compares two string arrays on equality

  \param[in] expected the array of expected values
  \param[in] expectedLength
                      the number of expected values
  \param[in] actual   the array of actual values to be checked
  \param[in] actualLength
                      the number of actual values
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
 */
void assertEqualsArrayString(char * const expected[],
                             int expectedLength,
                             char * const actual[],
                             int actualLength,
                             char const * messageFormat,
                             ...);

/*************** assertions - arrays: end *************************************/

/*************** assertions - pointers types: start ***************************/

/*!
  \brief Compares two pointers to point to the same memory, or to contain both
  the value NULL

  \param[in] expected the expected pointer from int
  \param[in] actual   the actual pointer from int
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointer(int * const expected,
                         int * const actual,
                         char const * messageFormat,
                         ...);

/*!
  \brief Compares two pointers from unsigned integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned integer
  \param[in] actual   the actual pointer from unsigned integer
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerUnsigned(unsigned int * const expected,
                                 unsigned int * const actual,
                                 char const * messageFormat,
                                 ...);

/*!
  \brief Compares two pointers to point to the same memory, or to contain both
  the value NULL

  \param[in] expected the expected pointer from char
  \param[in] actual   the actual pointer from char
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerChar(char * const expected,
                             char * const actual,
                             char const * messageFormat,
                             ...);

/*!
  \brief Compares two pointers from unsigned char
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned char
  \param[in] actual   the actual pointer from unsigned char
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerUnsignedChar(unsigned char * const expected,
                                     unsigned char * const actual,
                                     char const * messageFormat,
                                     ...);

/*!
  \brief Compares two pointers from short integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from short int
  \param[in] actual   the actual pointer from short int
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerShort(short int * const expected,
                              short int * const actual,
                              char const * messageFormat,
                              ...);

/*!
  \brief Compares two pointers from unsigned short integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned short int
  \param[in] actual   the actual pointer from unsigned short int
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerUnsignedShort(unsigned short int * const expected,
                                      unsigned short int * const actual,
                                      char const * messageFormat,
                                      ...);

/*!
  \brief Compares two pointers from long
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long integer
  \param[in] actual   the actual pointer from long integer
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerLong(long * const expected,
                             long * const actual,
                             char const * messageFormat,
                             ...);

/*!
  \brief Compares two pointers from unsigned long
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned long
  \param[in] actual   the actual pointer from unsigned long
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerUnsignedLong(unsigned long * const expected,
                                     unsigned long * const actual,
                                     char const * messageFormat,
                                     ...);

/*!
  \brief Compares two pointers from long long integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long long integer
  \param[in] actual   the actual pointer from long long integer
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerLongLong(long long int * const expected,
                                 long long int * const actual,
                                 char const * messageFormat,
                                 ...);

/*!
  \brief Compares two pointers from unsigned long long integer
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from unsigned long long integer
  \param[in] actual   the actual pointer from unsigned long long integer
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerUnsignedLongLong(unsigned long long int * const expected,
                                         unsigned long long int * const actual,
                                         char const * messageFormat,
                                         ...);

/*!
  \brief Compares two pointers from float
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from float
  \param[in] actual   the actual pointer from float
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerFloat(float * const expected,
                              float * const actual,
                              char const * messageFormat,
                              ...);

/*!
  \brief Compares two pointers from double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from double
  \param[in] actual   the actual pointer from double
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerDouble(double * const expected,
                               double * const actual,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two pointers from long double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long double
  \param[in] actual   the actual pointer from long double
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerLongDouble(long double * const expected,
                                   long double * const actual,
                                   char const * messageFormat,
                                   ...);

/*!
  \brief Compares two pointers from float
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from float complex
  \param[in] actual   the actual pointer from float complex
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerFloatComplex(float _Complex * const expected,
                                     float _Complex * const actual,
                                     const char * messageFormat,
                                     ...);

/*!
  \brief Compares two pointers from double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from double complex
  \param[in] actual   the actual pointer from double complex
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerDoubleComplex(double _Complex * const expected,
                                      double _Complex * const actual,
                                      char const * messageFormat,
                                      ...);

/*!
  \brief Compares two pointers from long double
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from long double complex
  \param[in] actual   the actual pointer from long double complex
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerLongDoubleComplex(long double _Complex * const expected,
                                          long double _Complex * const actual,
                                          char const * messageFormat,
                                          ...);
/*!
  \brief Compares two pointers from string
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from string
  \param[in] actual   the actual pointer from string
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerString(char ** const expected,
                               char ** const actual,
                               char const * messageFormat,
                               ...);

/*!
  \brief Compares two pointers from void
  to point to the same memory, or to contain both the value NULL

  \param[in] expected the expected pointer from void
  \param[in] actual   the actual pointer from void
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertEqualsPointerVoid(void * const expected,
                             void * const actual,
                             char const * messageFormat,
                             ...);

/*************** assertions - pointers types: end *****************************/

/*************** assertions - boolean and fail: start *************************/

/*!
  \brief Checks a logical value if it is true

  \param[in] actual  the actual value to be checked
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertTrue(bool actual,
                char const * messageFormat,
                ...);

/*!
  \brief Checks a logical value if it is false

  \param[in] actual  the actual value to be checked
  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void assertFalse(bool actual,
                 char const * messageFormat,
                 ...);

/*!
  \brief Lets the test fail and outputs an error message

  \param[in] messageFormat
                      descriptive message for the check, assert, providing
                      information about the comparision or the parameters;
                      it is the same format, as printf, fprintf of the
                      standard C library
  \param[in] ...      arguments of the format
*/
void fail(char const * const messageFormat,
          ...);

/*************** assertions - boolean and fail: end ***************************/

/*************** assertions: end **********************************************/

/*************** test runs and invocation: start ******************************/

/*!
  \brief Walks through the command-line parameters and configures the whole test

  \details Parameters are

  | Name              | Meaning                                                       |
  |-------------------|---------------------------------------------------------------|
  | -h, --help        | Prints the help text and stops further execution              |
  | --no-colours      | Disables colours, default: ANSI colours are enabled           |
  | --only-errors     | Prints failed asserts, and summary over all                   |
  | --only-summary    | Prints only the summary                                       |
  | --output `MyFile` | Directs output into file `MyFile`; coloured output is then    |
  |                 ^ | disabled                                                      |

  Output is formatted according to Markdown rules

  \param[in] argumentCount     number of parameters
  \param[in] cmdLineArguments  list of parameter, the first element in the list is
                               assumed to contain the name of the program called on
                               by the shell; the name is used in the help text

  \retval 0  no errors
  \retval -1 stop the test, print the help text
  \retval 1  errors occurred
*/
int testerConfigure(int argumentCount,
                    char** cmdLineArguments);

/*!
  \brief Runs a single test

  \param[in] test test to be run

  \retval 0   test ran and no errors occurred
  \retval -1  test ran and produced a wrong return value
  \retval -2  test did not run because of an error in the configuration, see
                  testerConfigure(int, char**)
  \retval -3  in case the preparation failed, i.e. method
                  beforeTestMethod returned a non-zero value
  \retval -4  in case concluding work failed, i.e. method
                  afterTestMethod returned a non-zero value
*/
int testerRunSingle(CommonTest * test);

/*!
  \brief Runs a test

  \details A successful test is to be expected to return 0.

  \param[in] testName    name of the test, as in CommonTest
  \param[in] testMethod  test method, see CommonTest

  \return the same values as documented in testerRunSingle(CommonTest*)
*/
int testerRunTest(char* testName,
                  int (*testMethod)(void));

/*!
  \brief Runs a test suite

  \param[in]  suite  test suite to run

  \return 0  in case of no errors, and a non-zero value if any error occurred
  \retval 0  if all tests, the preparing, and the concluding method returned 0
  \retval p  positive value, giving the number of unsuccessful tests
  \retval n  negative value, the exit code of the preparing method,
             or the concluding method
*/
int testerRunSuite(TestSuite* suite);

/*************** test runs and invocation: end ********************************/

/*************** test logging: start ******************************************/

/*!
  \brief Prints into the test output

  \details Called within methods beforeTestMethod and afterTestMethod, this
  output is written into a Markdown formatted code-block.

  \param[in] format  the same format, as printf, fprintf of the standard C
                     library
  \param[in] ...     arguments for the format
*/
void testerLog(char const * const format,
               ...);

/*************** test logging: end ********************************************/

#endif // _UNITTESTER_H
